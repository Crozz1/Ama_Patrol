package com.ama_patrol.data.models.client

class Maintenance {
}