package com.ama_patrol.data.models.client

 data class ModelLearning (
        val title: String,
        val image: String,
        val link: String
    )
